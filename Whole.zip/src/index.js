import React, { useState, useEffect } from 'react';
import { createRoot } from 'react-dom/client';
import ReactSection from './components/ReactSection';

const HeroSection = () => {
  return (
    <section className="hero-section">
      <div className="hero-overlay"></div>
      <div className="hero-content">
        <h1>Discover Your Next Adventure</h1>
        <p>Explore the world with our expertly crafted tours</p>
        <a href="#tours" className="hero-cta">Explore Tours</a>
      </div>
    </section>
  );
};

const ReviewSection = () => {
  const [currentReviewIndex, setCurrentReviewIndex] = useState(0);
  const reviews = [
    {
      text: "Review text goes here.",
      image: "images/r.jpeg"
    },
    {
      text: "Review text goes here.",
      image: "images/s.jpeg"
    },
    {
      text: "Review text goes here.",
      image: "images/t.jpeg"
    },
    {
      text: "Review text goes here.",
      image: "images/r.jpeg"
    }
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentReviewIndex((prevIndex) => (prevIndex + 1) % reviews.length);
    }, 3000); // Change review every 3 seconds

    return () => clearInterval(interval);
  }, [reviews.length]);

  return (
    <div className="reviews-grid">
      <div className="review-box">
        <img src={reviews[currentReviewIndex].image} alt="Profile Image" className="profile-image" />
        <p>{reviews[currentReviewIndex].text}</p>
      </div>
    </div>
  );
};

const App = () => {
  return (
    <div>
      <HeroSection />
      <ReviewSection />
      <ReactSection />
    </div>
  );
};

// Render the App component
const container = document.getElementById('root');
const root = createRoot(container);
root.render(<App />);
